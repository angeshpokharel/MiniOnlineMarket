package com.waa.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiniOnlineMarketApplicationTests {

	@Test
	void contextLoads() {
	}

}
